# xyflow Pro License

**Version 1.0**

## Grant of License

Subject to the terms and conditions of this License and upon maintaining a valid subscription to React Flow Pro, webkid GmbH ("xyflow") hereby grants you a perpetual, worldwide, non-exclusive, non-transferable license to:

1. **Use** the pro examples, templates, and related documentation ("pro content")
2. **Modify** the pro content for your own projects
3. **Integrate** the pro content into your applications, whether commercial or non-commercial
4. **Distribute** applications that incorporate the pro content

## Perpetual Rights

Once you have obtained access to any pro content through a valid subscription, your rights to that specific content continue permanently, even if your subscription expires or is terminated. However, access to new pro content requires an active subscription.

## Restrictions

You may **not**:

- Redistribute the pro content as standalone examples or templates
- Share your subscription access with others
- Remove or modify any copyright notices or attributions
- Use the pro content in a way that directly competes with xyflow's business model

## Ownership

xyflow retains all right, title, and interest in the pro content. This License does not grant you any rights to xyflow's trademarks or branding.

## Support and Updates

This License does not entitle you to support, maintenance, or updates. These services require an active subscription.

## Disclaimer

THE PRO CONTENT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.

## Termination

This License terminates automatically if you breach any of its terms. Upon termination, you must cease distribution of applications that incorporate the pro content, but applications already distributed may continue to operate.

---

**Copyright © 2025 webkid GmbH. All rights reserved.**

_For questions about this License, contact: info@xyflow.com_

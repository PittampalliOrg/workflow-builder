export const getId = (prefix = 'node') => `${prefix}_${Math.random() * 10000}`;
